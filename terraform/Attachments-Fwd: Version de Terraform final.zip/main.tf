terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }

    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 3.0"
    }
  }
}

# ============================================================
# Providers
# ============================================================

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

provider "azuread" {
}

# ============================================================
# Resource Group
# ============================================================

resource "azurerm_resource_group" "main" {
  name     = var.resource_group_name
  location = var.location

  tags = var.tags
}

# ============================================================
# Invite external user into Microsoft Entra ID
# ============================================================

resource "azuread_invitation" "user" {
  user_email_address = var.user_email
  redirect_url       = "https://portal.azure.com"

  message {
    body = "Invitation pour accéder à votre environnement Azure."
  }
}

# ============================================================
# Contributor - ONLY on this Resource Group
# ============================================================

resource "azurerm_role_assignment" "contributor" {
  scope                = azurerm_resource_group.main.id
  role_definition_name = "Contributor"

  principal_id   = azuread_invitation.user.user_id
  principal_type = "User"
}

# ============================================================
# Azure Static Web App - Angular
# ============================================================

resource "azurerm_static_web_app" "angular" {
  name                = var.static_web_app_name
  resource_group_name = azurerm_resource_group.main.name
  location            = var.static_web_app_location

  sku_tier = "Free"
  sku_size = "Free"

  tags = var.tags
}

# ============================================================
# Azure Container Registry
# ============================================================

resource "azurerm_container_registry" "main" {
  name                = var.container_registry_name
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  sku           = "Basic"
  admin_enabled = false

  tags = var.tags
}

# ============================================================
# User Assigned Managed Identity for Container App
# ============================================================

resource "azurerm_user_assigned_identity" "container_app" {
  name                = var.container_app_identity_name
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  tags = var.tags
}

# ============================================================
# Allow Container App identity to pull images from ACR
# ============================================================

resource "azurerm_role_assignment" "acr_pull" {
  scope                = azurerm_container_registry.main.id
  role_definition_name = "AcrPull"

  principal_id = azurerm_user_assigned_identity.container_app.principal_id
}

# ============================================================
# Azure Container Apps Environment
# ============================================================

resource "azurerm_container_app_environment" "main" {
  name                = var.container_app_environment_name
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  tags = var.tags
}

# ============================================================
# Azure Container App - ASP.NET Core API
# ============================================================

resource "azurerm_container_app" "api" {
  name                         = var.container_app_name
  container_app_environment_id = azurerm_container_app_environment.main.id
  resource_group_name          = azurerm_resource_group.main.name

  revision_mode = "Single"

  identity {
    type = "UserAssigned"

    identity_ids = [
      azurerm_user_assigned_identity.container_app.id
    ]
  }

  registry {
    server   = azurerm_container_registry.main.login_server
    identity = azurerm_user_assigned_identity.container_app.id
  }

  template {
    min_replicas = var.container_app_min_replicas
    max_replicas = var.container_app_max_replicas

    container {
      name = "api"

      image = var.use_acr_image ? "${azurerm_container_registry.main.login_server}/${var.container_image_name}:${var.container_image_tag}" : var.bootstrap_container_image

      cpu    = var.container_cpu
      memory = var.container_memory
    }
  }

  ingress {
    external_enabled = true
    target_port = var.use_acr_image ? var.container_target_port : var.bootstrap_target_port

    traffic_weight {
      percentage      = 100
      latest_revision = true
    }
  }

  depends_on = [
    azurerm_role_assignment.acr_pull
  ]

  tags = var.tags
}

# ============================================================
# Outputs
# ============================================================

output "resource_group_name" {
  value = azurerm_resource_group.main.name
}

output "static_web_app_url" {
  value = "https://${azurerm_static_web_app.angular.default_host_name}"
}

output "acr_name" {
  value = azurerm_container_registry.main.name
}

output "acr_login_server" {
  value = azurerm_container_registry.main.login_server
}

output "container_app_url" {
  value = "https://${azurerm_container_app.api.latest_revision_fqdn}"
}

output "acr_image_to_push" {
  value = "${azurerm_container_registry.main.login_server}/${var.container_image_name}:${var.container_image_tag}"
}
