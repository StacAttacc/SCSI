variable "subscription_id" {
  description = "Azure Subscription ID"
  type        = string
}

variable "user_email" {
  description = "External user to invite to Microsoft Entra ID"
  type        = string
  default     = "s.valitiana@gmail.com"
}

variable "resource_group_name" {
  description = "Azure Resource Group name"
  type        = string
  default     = "rg-s-valitiana-dev"
}

variable "location" {
  description = "Default Azure region for supported resources"
  type        = string
  default     = "East US"
}

variable "static_web_app_location" {
  description = "Azure region for Static Web Apps"
  type        = string
  default     = "East US 2"
}

variable "static_web_app_name" {
  description = "Azure Static Web App name"
  type        = string
  default     = "swa-s-valitiana-dev"
}

variable "container_registry_name" {
  description = "Azure Container Registry name. Must be globally unique and alphanumeric."
  type        = string
  default     = "acrsvalitianadev"
}

variable "container_app_identity_name" {
  description = "Managed Identity name used by Azure Container Apps"
  type        = string
  default     = "id-ca-s-valitiana-dev"
}

variable "container_app_environment_name" {
  description = "Azure Container Apps Environment name"
  type        = string
  default     = "cae-s-valitiana-dev"
}

variable "container_app_name" {
  description = "Azure Container App name"
  type        = string
  default     = "ca-api-s-valitiana-dev"
}

variable "container_image_name" {
  description = "Container image repository name in ACR"
  type        = string
  default     = "myapi"
}

variable "container_image_tag" {
  description = "Container image tag"
  type        = string
  default     = "latest"
}

variable "container_target_port" {
  description = "Port exposed by the ASP.NET Core container"
  type        = number
  default     = 8080
}

variable "container_cpu" {
  description = "CPU allocated to the Container App"
  type        = number
  default     = 0.25
}

variable "container_memory" {
  description = "Memory allocated to the Container App"
  type        = string
  default     = "0.5Gi"
}

variable "container_app_min_replicas" {
  description = "Minimum number of Container App replicas"
  type        = number
  default     = 0
}

variable "container_app_max_replicas" {
  description = "Maximum number of Container App replicas"
  type        = number
  default     = 1
}

variable "use_acr_image" {
  description = "When false, use a public bootstrap image so the first Terraform apply succeeds before the application image exists in ACR."
  type        = bool
  default     = false
}

variable "bootstrap_container_image" {
  description = "Public image used only for the initial Container App deployment."
  type        = string
  default     = "mcr.microsoft.com/azuredocs/containerapps-helloworld:latest"
}

variable "bootstrap_target_port" {
  description = "Port used by the Hello World bootstrap container"
  type        = number
  default     = 80
}

variable "tags" {
  description = "Tags applied to Azure resources"
  type        = map(string)

  default = {
    environment = "dev"
    managed-by  = "terraform"
    owner       = "s-valitiana"
  }
}
