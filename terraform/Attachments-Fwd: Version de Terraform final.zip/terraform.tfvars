# Azure subscription utilisée par Terraform
# Remplace la valeur ci-dessous par ton Subscription ID.
subscription_id = "5ba2f5ba-b174-4ad8-b4f3-fa773f2a9c0a"

location                = "East US"
static_web_app_location = "East US 2"

# First deployment uses a public bootstrap image.
# After pushing myapi:latest into ACR, change this to true.
use_acr_image = false

bootstrap_container_image = "mcr.microsoft.com/azuredocs/containerapps-helloworld:latest"

bootstrap_target_port = 80
container_target_port = 8080

# Cost optimization for DEV
container_cpu              = 0.25
container_memory           = "0.5Gi"
container_app_min_replicas = 0
container_app_max_replicas = 1
